import { config } from 'dotenv';
config();

import '@/ai/flows/bio-generator.ts';
import '@/ai/flows/publication-integrator.ts';